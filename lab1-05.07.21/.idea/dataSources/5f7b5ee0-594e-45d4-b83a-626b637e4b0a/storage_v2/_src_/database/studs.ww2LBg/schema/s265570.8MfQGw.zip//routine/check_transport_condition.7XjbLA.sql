create function check_transport_condition() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (SELECT status FROM transport WHERE trans_id = new.trans_id AND status = 'available') IS NULL THEN
            RAISE EXCEPTION 'Cannot set not available transport to mission';
        ELSE RETURN new;
        END IF;
    END;
$$;

alter function check_transport_condition() owner to s265570;

