create function get_combat_candidates(n integer DEFAULT 1) returns employee
    language plpgsql
as
$$
BEGIN
        SELECT emp_id FROM employee
            JOIN position USING (pos_id)
            JOIN missions_emp USING (emp_id)
            JOIN mission USING (miss_id)
        WHERE rank IS NOT NULL OR !~~ ''
        ORDER BY is_married DESC, end_date_and_time DESC, hiring_date DESC
        LIMIT n;
    END;
$$;

alter function get_combat_candidates(integer) owner to s265570;

