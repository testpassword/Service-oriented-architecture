create function check_is_military_on_mission() returns trigger
    language plpgsql
as
$$
DECLARE enemy TEXT;
    DECLARE emp_rank TEXT;
    BEGIN
        enemy = (SELECT enemies FROM mission WHERE miss_id = new.miss_id);
        emp_rank = (SELECT rank FROM position JOIN employee USING (pos_id) WHERE emp_id = new.emp_id);
        IF enemy IS NOT NULL AND emp_rank IS NULL THEN
            RAISE EXCEPTION 'Cannot set not military employee to a combat mission';
        ELSE RETURN new;
        END IF;
    END;
$$;

alter function check_is_military_on_mission() owner to s265570;

